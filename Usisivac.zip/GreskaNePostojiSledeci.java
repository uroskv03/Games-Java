package lab3zad1;

public class GreskaNePostojiSledeci extends Exception {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GreskaNePostojiSledeci() {
		super("Ne postoji sledeci element");
	}
}
