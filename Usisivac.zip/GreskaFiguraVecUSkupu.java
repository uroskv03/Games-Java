package lab3zad1;

public class GreskaFiguraVecUSkupu extends Exception {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GreskaFiguraVecUSkupu() {
		super("Data figura je vec u skupu");
		
	}
}
