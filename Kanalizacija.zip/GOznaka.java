package lab3zad2;

public class GOznaka extends Exception {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GOznaka() {
		super("Ne moze se oznaciti dati kvadrat");
	}
}
